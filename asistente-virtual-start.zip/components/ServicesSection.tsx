import React from 'react';
import { SERVICES_DATA, PAYMENT_METHODS } from '../constants';
import { Service, ServiceType } from '../types';
import { Button } from './ui/Button';
import { Card } from './ui/Card';

const CheckCircleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

const WrenchScrewdriverIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M11.42 15.17L17.25 21A2.652 2.652 0 0021 17.25l-5.877-5.877M11.42 15.17l2.472-2.472a3.75 3.75 0 00-5.303-5.303L6.25 9.75M11.42 15.17L6.25 9.75m5.17 5.42l-2.472 2.472a3.75 3.75 0 01-5.303-5.303L9.75 6.25m5.17 5.42l2.472-2.472a3.75 3.75 0 00-5.303-5.303L9.75 6.25" />
    </svg>
);


const PaymentLogos: React.FC = () => (
  <div className="mt-6">
    <p className="text-xs text-neutral-default mb-2">Aceptamos todos los métodos de pago:</p>
    <div className="flex flex-wrap justify-center items-center gap-2 grayscale opacity-75">
      {PAYMENT_METHODS.map(method => (
        <img key={method.name} src={method.logoUrl} alt={method.name} title={method.name} className="h-6 max-w-[60px] object-contain"/>
      ))}
    </div>
  </div>
);

export const ServicesSection: React.FC<{ id: string; onStartPlan: () => void; }> = ({ id, onStartPlan }) => {
  const service = SERVICES_DATA[0]; // There is only one service plan

  return (
    <section id={id} className="py-16 md:py-24 bg-neutral-light">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mx-auto">
          <Card className="flex flex-col" shadow="xl" hoverEffect>
              <div className="p-8 flex-grow">
                <h2 className="text-3xl sm:text-4xl font-bold text-primary mb-3 text-center">{service.title}</h2>
                <p className="text-4xl font-bold text-neutral-dark mb-4 text-center">{service.price}</p>
                 <p className="text-lg text-neutral-default text-center mb-8">{service.description}</p>
                
                <ul className="space-y-3 mb-6">
                  {service.features.map((feature, index) => (
                    <li key={index} className="flex items-start">
                      <CheckCircleIcon className="h-6 w-6 text-primary mr-3 flex-shrink-0 mt-0.5" />
                      <span className="text-neutral-default">{feature}</span>
                    </li>
                  ))}
                </ul>
                {service.supportNote && (
                    <div className="mt-6 pt-4 border-t border-gray-200">
                         <div className="flex items-start">
                            <WrenchScrewdriverIcon className="h-6 w-6 text-neutral-default mr-3 flex-shrink-0 mt-0.5" />
                             <p className="text-sm text-neutral-default whitespace-pre-line">{service.supportNote.replace(/^🔧\s*/, '')}</p>
                        </div>
                    </div>
                )}
              </div>
              <div className="p-8 bg-gray-50 rounded-b-xl">
                 <Button 
                    variant="primary" 
                    size="lg" 
                    className="w-full text-xl"
                    onClick={onStartPlan}
                  >
                  {service.ctaText}
                </Button>
                <PaymentLogos />
              </div>
            </Card>
        </div>
      </div>
    </section>
  );
};